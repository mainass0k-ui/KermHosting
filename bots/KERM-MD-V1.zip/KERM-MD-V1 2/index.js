/*
_  ______   _____ _____ _____ _   _
| |/ / ___| |_   _| ____/___ | | | |
| ' / |  _    | | |  _|| |   | |_| |
| . \ |_| |   | | | |__| |___|  _  |
|_|\_\____|   |_| |_____\____|_| |_|

ANYWAY, YOU MUST GIVE CREDIT TO MY CODE WHEN COPY IT
CONTACT ME HERE +237656520674/
YT: KermHackTools
Github: Kgtech-cmr
*/

const {
default: makeWASocket,
useMultiFileAuthState,
DisconnectReason,
jidNormalizedUser,
getContentType,
fetchLatestBaileysVersion,
Browsers
} = require('@whiskeysockets/baileys')

// Activer stdin pour la lecture du terminal
process.stdin.resume();
process.stdin.setEncoding('utf-8');

const l = console.log
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, runtime, sleep, fetchJson } = require('./lib/functions')
const fs = require('fs')
const ff = require('fluent-ffmpeg')
const P = require('pino')
const config = require('./config')
const rankCommand = require('./plugins/rank')
const qrcode = require('qrcode-terminal')
const StickersTypes = require('wa-sticker-formatter')
const util = require('util')
const { sms,downloadMediaMessage } = require('./lib/msg')
const axios = require('axios')
const { File } = require('megajs')
const { fromBuffer } = require('file-type')
const bodyparser = require('body-parser')
const { tmpdir } = require('os')
const Crypto = require('crypto')
const path = require('path')
const readline = require('readline')
const prefix = config.PREFIX

const ownerNumber = ['237659535227']

//===================SESSION-AUTH============================
if (!fs.existsSync(__dirname + '/auth_info_baileys/creds.json')) {
    if (!config.SESSION_ID) {
        console.log('⚠️ Aucune session trouvée, utilisation du pairing code...');
    } else {
        try {
            let sessdata = config.SESSION_ID;
            if (sessdata.includes('KERM-MD-V1~')) {
                sessdata = sessdata.replace("KERM-MD-V1~", '');
            }
            
            console.log('📥 Downloading session from MEGA...');
            const filer = File.fromURL(`https://mega.nz/file/${sessdata}`);
            
            filer.download((err, data) => {
                if (err) {
                    console.log('❌ Error downloading session:', err.message);
                    console.log('📱 Fallback vers pairing code...');
                    return;
                }
                fs.writeFile(__dirname + '/auth_info_baileys/creds.json', data, (err) => {
                    if (err) {
                        console.log('❌ Error saving session:', err.message);
                    } else {
                        console.log("✅ SESSION DOWNLOADED COMPLETED");
                    }
                });
            });
        } catch (error) {
            console.log('❌ Error:', error.message);
            console.log('📱 Fallback vers pairing code...');
        }
    }
}

const express = require("express");
const app = express();
const port = process.env.PORT || 9090;


async function connectToWA() {
console.log("\n\x1b[36m%s\x1b[0m", "╔══════════════════════════════════════╗");
console.log("\x1b[36m║  \x1b[33m🔷 \x1b[32mKERM-MD-V1 \x1b[31mCONNECTION \x1b[35mPROCESS \x1b[36m ║");
console.log("\x1b[36m╚══════════════════════════════════════╝\x1b[0m\n");

const { state, saveCreds } = await useMultiFileAuthState(__dirname + '/auth_info_baileys/')
var { version } = await fetchLatestBaileysVersion()

const conn = makeWASocket({
        logger: P({ level: 'silent' }),
        printQRInTerminal: false,
        browser: Browsers.macOS("Firefox"),
        syncFullHistory: true,
        auth: state,
        version
        })

// ===== PAIRING CODE SI PAS DE SESSION =====
if (!fs.existsSync(__dirname + '/auth_info_baileys/creds.json')) {
    console.log("\n\x1b[36m┌──────────────────────────────────────────────┐\x1b[0m");
    console.log("\x1b[36m│  \x1b[38;5;201m📱 \x1b[38;5;46mMODE \x1b[38;5;226mPAIRING \x1b[38;5;51mCODE \x1b[38;5;196mACTIVÉ \x1b[36m           │\x1b[0m");
    console.log("\x1b[36m└──────────────────────────────────────────────┘\x1b[0m\n");
    
    // Créer une interface readline
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    
    // Demander le numéro avec style
    console.log("\x1b[38;5;226m✦ ─────────────────────────────── ✦\x1b[0m");
    console.log("\x1b[38;5;51m  ⚡ \x1b[38;5;46mKERM MD \x1b[38;5;196mCONNEXION \x1b[38;5;226mRAPIDE \x1b[0m");
    console.log("\x1b[38;5;226m✦ ─────────────────────────────── ✦\x1b[0m\n");
    
    const phoneNumber = await new Promise((resolve) => {
        rl.question("\x1b[38;5;39m📲 \x1b[38;5;226mEntrez votre numéro : \x1b[38;5;46m", (answer) => {
            console.log("\x1b[0m");
            resolve(answer);
        });
    });
    rl.close();
    
    const number = phoneNumber.replace(/[^0-9]/g, "");
    
    if (!number || number.length < 10) { 
        console.log("\n\x1b[41m\x1b[37m❌ ERREUR: Numéro invalide! \x1b[0m\n"); 
        process.exit(1); 
    }
    
    try {
        console.log("\n\x1b[38;5;214m⏳ Génération du code de pairage...\x1b[0m\n");
        const pairingCode = await conn.requestPairingCode(number);
        console.log("\x1b[38;5;226m╔══════════════════════════════════════════════╗\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;46m✨ \x1b[38;5;201mCODE DE PAIRAGE \x1b[38;5;46m✨ \x1b[38;5;226m           ║\x1b[0m");
        console.log("\x1b[38;5;226m╠══════════════════════════════════════════════╣\x1b[0m");
        console.log("\x1b[38;5;226m║                                              ║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;196m██████╗ ██████╗ ██████╗ ███████╗   \x1b[38;5;226m║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;196m██╔══██╗██╔══██╗██╔══██╗██╔════╝   \x1b[38;5;226m║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;196m██████╔╝██████╔╝██║  ██║█████╗     \x1b[38;5;226m║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;196m██╔══██╗██╔══██╗██║  ██║██╔══╝     \x1b[38;5;226m║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;196m██║  ██║██║  ██║██████╔╝███████╗   \x1b[38;5;226m║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;196m╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝   \x1b[38;5;226m║\x1b[0m");
        console.log("\x1b[38;5;226m║                                              ║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;226m╔══════════════════════════════╗ \x1b[38;5;226m   ║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;226m║  \x1b[48;5;226m\x1b[30m                              \x1b[0m\x1b[38;5;226m ║   ║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;226m║  \x1b[48;5;226m\x1b[30m       \x1b[48;5;226m\x1b[38;5;196m  \x1b[38;5;226mpairing \x1b[38;5;46m  \x1b[38;5;226m    \x1b[0m\x1b[38;5;226m ║   ║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;226m║  \x1b[48;5;226m\x1b[30m                              \x1b[0m\x1b[38;5;226m ║   ║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;226m╚══════════════════════════════╝ \x1b[38;5;226m   ║\x1b[0m");
        console.log("\x1b[38;5;226m║                                              ║\x1b[0m");
        console.log("\x1b[38;5;226m║  \x1b[38;5;51m📱 CODE: \x1b[38;5;226m[\x1b[38;5;46m" + pairingCode + "\x1b[38;5;226m] \x1b[38;5;226m            ║\x1b[0m");
        console.log("\x1b[38;5;226m║                                              ║\x1b[0m");
        console.log("\x1b[38;5;226m╚══════════════════════════════════════════════╝\x1b[0m\n");
        console.log("\x1b[38;5;226m✦ \x1b[38;5;39m📌 \x1b[38;5;46mWhatsApp > 3 points > Appareils liés \x1b[38;5;226m✦\x1b[0m");
        console.log("\x1b[38;5;39m  🔗 Lier un appareil \x1b[38;5;226m> \x1b[38;5;46mScanner ce code \x1b[0m\n");
    } catch (err) { 
        console.log("\n\x1b[41m\x1b[37m❌ ERREUR: " + err.message + "\x1b[0m\n"); 
        process.exit(1); 
    }
}
    
conn.ev.on('connection.update', (update) => {
const { connection, lastDisconnect } = update
if (connection === 'close') {
if (lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut) {
connectToWA()
}
} else if (connection === 'open') {
console.log('\n\x1b[42m\x1b[30m♻️ INSTALLATION DES PLUGINS... \x1b[0m')
const path = require('path');
fs.readdirSync("./plugins/").forEach((plugin) => {
if (path.extname(plugin).toLowerCase() == ".js") {
require("./plugins/" + plugin);
}
});
console.log('\x1b[42m\x1b[30m✅ PLUGINS INSTALLÉS AVEC SUCCÈS \x1b[0m')
console.log('\x1b[42m\x1b[30m✅ KERM_MD-V1 CONNECTÉ À WHATSAPP \x1b[0m\n')

let up = `*╭──────────────●●►*
> *➺Kᴇʀᴍ_ᴍᴅ-ᴠ1 ᴄᴏɴɴᴇᴄᴛᴇᴅ sᴜᴄᴄᴇssғᴜʟʏ ᴛʏᴘᴇ .ᴍᴇɴᴜ ᴛᴏ ᴄᴏᴍᴍᴀɴᴅ ʟɪsᴛ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴋɢ ᴛᴇᴄʜ✅*

> *❁ᴊᴏɪɴ ᴏᴜʀ ᴡʜᴀᴛsᴀᴘᴘ ᴄʜᴀɴɴᴇʟ ғᴏʀ ᴜᴘᴅᴀᴛᴇs Kᴇʀᴍ_ᴍᴅ-ᴠ1❁*

*https://whatsapp.com/channel/0029Vafn6hc7DAX3fzsKtn45*

> *❁ᴊᴏɪɴ ᴏᴜʀ ʏᴏᴜᴛᴜʙᴇ ᴄʜᴀɴɴᴇʟ ғᴏʀ ᴜᴘᴅᴀᴛᴇs Kᴇʀᴍ_ᴍᴅ-ᴠ1❁*

*https://youtube.com/@KermHackTools-s9s*

*╭⊱✫🐲 KERM-MD-V1 🐲✫⊱╮*
*│✫➠ - 📂REPOSITORY NAME:* *KERM-MD-V1*
*│✫➠ - 📃DESCRIPTION:* *THE WORLD BEST WHATSAPP BOT♻️*
*│✫➠ - 🛡️OWNER:* *KG TECH🇨🇲*
*│✫➠ - 🌐URL:* *https://github.com/Kgtech-cmr/KERM-MD-V1*

*YOUR BOT ACTIVE NOW ENJOY♥️🪄*\n\n*PREFIX: ${prefix}*

*╰──────────────●●►*`;
conn.sendMessage(conn.user.id, { image: { url: `https://files.catbox.moe/4czyo0.jpg` }, caption: up })

}
})
conn.ev.on('creds.update', saveCreds)  
        
//=============readstatus=======

conn.ev.on('messages.upsert', async(mek) => {
mek = mek.messages[0]
if (!mek.message) return	
mek.message = (getContentType(mek.message) === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast' && config.AUTO_READ_STATUS === "true"){
await conn.readMessages([mek.key])
}
const m = sms(conn, mek)
const type = getContentType(mek.message)
const content = JSON.stringify(mek.message)
const from = mek.key.remoteJid
const quoted = type == 'extendedTextMessage' && mek.message.extendedTextMessage.contextInfo != null ? mek.message.extendedTextMessage.contextInfo.quotedMessage || [] : []
const body = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : ''
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const args = body.trim().split(/ +/).slice(1)
const q = args.join(' ')
const isGroup = from.endsWith('@g.us')
const sender = mek.key.fromMe ? (conn.user.id.split(':')[0]+'@s.whatsapp.net' || conn.user.id) : (mek.key.participant || mek.key.remoteJid)
const senderNumber = sender.split('@')[0]
const botNumber = conn.user.id.split(':')[0]
const pushname = mek.pushName || 'Sin Nombre'
const isMe = botNumber.includes(senderNumber)
const isOwner = ownerNumber.includes(senderNumber) || isMe
const botNumber2 = await jidNormalizedUser(conn.user.id);
const groupMetadata = isGroup ? await conn.groupMetadata(from).catch(e => {}) : ''
const groupName = isGroup ? groupMetadata.subject : ''
const participants = isGroup ? await groupMetadata.participants : ''
const groupAdmins = isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber2) : false
const isAdmins = isGroup ? groupAdmins.includes(sender) : false
const isReact = m.message.reactionMessage ? true : false
const reply = (teks) => {
conn.sendMessage(from, { text: teks }, { quoted: mek })
}
        
conn.sendFileUrl = async (jid, url, caption, quoted, options = {}) => {
              let mime = '';
              let res = await axios.head(url)
              mime = res.headers['content-type']
              if (mime.split("/")[1] === "gif") {
                return conn.sendMessage(jid, { video: await getBuffer(url), caption: caption, gifPlayback: true, ...options }, { quoted: quoted, ...options })
              }
              let type = mime.split("/")[0] + "Message"
              if (mime === "application/pdf") {
                return conn.sendMessage(jid, { document: await getBuffer(url), mimetype: 'application/pdf', caption: caption, ...options }, { quoted: quoted, ...options })
              }
              if (mime.split("/")[0] === "image") {
                return conn.sendMessage(jid, { image: await getBuffer(url), caption: caption, ...options }, { quoted: quoted, ...options })
              }
              if (mime.split("/")[0] === "video") {
                return conn.sendMessage(jid, { video: await getBuffer(url), caption: caption, mimetype: 'video/mp4', ...options }, { quoted: quoted, ...options })
              }
              if (mime.split("/")[0] === "audio") {
                return conn.sendMessage(jid, { audio: await getBuffer(url), caption: caption, mimetype: 'audio/mpeg', ...options }, { quoted: quoted, ...options })
              }
            }
        
//================ownerreact==============
if(senderNumber.includes("23777777777")){
if(isReact) return
m.react("👑")
}
if(senderNumber.includes("237777777777")){
if(isReact) return
m.react("👑")
}
if(senderNumber.includes("923251869133")){
if(isReact) return
m.react("🦋")
   }

if(senderNumber.includes("447783770746")){
if(isReact) return
m.react("🎀")
   }

//==========================public react===============//
// Auto React 
if (!isReact && senderNumber !== botNumber) {
    if (config.AUTO_REACT === 'true') {
        const reactions = ['😊', '👍', '😂', '💯', '🔥', '🙏', '🎉', '👏', '😎', '🤖'];
        const randomReaction = reactions[Math.floor(Math.random() * reactions.length)];
        m.react(randomReaction);
    }
}

// Owner React
if (!isReact && senderNumber === botNumber) {
    if (config.OWNER_REACT === 'true') {
        const reactions = ['👑', '⭐', '💫', '✨', '⚡'];
        const randomOwnerReaction = reactions[Math.floor(Math.random() * reactions.length)];
        m.react(randomOwnerReaction);
    }
}
        
//============================HRTPACK============================       
        //=======HRT React 
if (!isReact && senderNumber !== botNumber) {
    if (config.HEART_REACT === 'true') {
            const reactions = ['💘', '💝', '💖', '💗', '💓', '💞', '💕', '❤️', '🧡', '💛', '💚', '💙', '💜', '🤎', '🖤', '🤍'];
           const randomReaction = reactions[Math.floor(Math.random() * reactions.length)];
        m.react(randomReaction);
    }
}
//=======HRT React 
if (!isReact && senderNumber === botNumber) {
    if (config.HEART_REACT === 'true') {
            const reactions = ['💘', '💝', '💖', '💗', '💓', '💞', '💕', '❤️', '🧡', '💛', '💚', '💙', '💜', '🤎', '🖤', '🤍'];
           const randomReaction = reactions[Math.floor(Math.random() * reactions.length)];
        m.react(randomReaction);
    }
}        
//=================================WORKTYPE=========================================== 
if(!isOwner && config.MODE === "private") return
if(!isOwner && isGroup && config.MODE === "inbox") return
if(!isOwner && isGroup && config.MODE === "groups") return
//======================================================





        
const events = require('./command')
const cmdName = isCmd ? body.slice(1).trim().split(" ")[0].toLowerCase() : false;
if (isCmd) {
const cmd = events.commands.find((cmd) => cmd.pattern === (cmdName)) || events.commands.find((cmd) => cmd.alias && cmd.alias.includes(cmdName))
if (cmd) {
if (cmd.react) conn.sendMessage(from, { react: { text: cmd.react, key: mek.key }})

try {
cmd.function(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply});
} catch (e) {
console.error("[PLUGIN ERROR] " + e);
}
}
}
events.commands.map(async(command) => {
if (body && command.on === "body") {
command.function(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply})
} else if (mek.q && command.on === "text") {
command.function(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply})
} else if (
(command.on === "image" || command.on === "photo") &&
mek.type === "imageMessage"
) {
command.function(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply})
} else if (
command.on === "sticker" &&
mek.type === "stickerMessage"
) {
command.function(conn, mek, m,{from, l, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply})
}});

})
}
app.get("/", (req, res) => {
res.send("HEY, KERM-MD-V1 STARTED ✅");
});
app.listen(port, () => console.log(`Server listening on port http://localhost:${port}`));
setTimeout(() => {
connectToWA()
}, 4000);
/**
 * Commande Couple Profile Pictures
 * Version avec envoi groupé
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "couplepp",
    alias: ["ppcouple", "couple", "cpp"],
    desc: "Get random matching anime profile pictures for couples",
    category: "random",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    try {
        await reply("🔄 *Recherche d'images de couple...*");

        const url = `https://kerm-apis.vercel.app/random/couplepp`;
        const res = await axios.get(url, { timeout: 10000 });

        if (!res.data || !res.data.status) {
            return reply("❌ Failed to get couple pictures");
        }

        const data = res.data.result;

        // Message avec les deux images
        const caption = `💑 *Matching Profile Pictures*\n\n` +
            `👦 *Boy:* [Click here](${data.male})\n` +
            `👧 *Girl:* [Click here](${data.female})\n\n` +
            `Creator: ${data.creator}`;

        // Envoyer d'abord l'image homme
        await conn.sendMessage(from, {
            image: { url: data.male },
            caption: `👦 *Boy Picture*\n\nCreator: ${data.creator}`
        }, { quoted: mek });

        // Puis l'image femme
        await conn.sendMessage(from, {
            image: { url: data.female },
            caption: `👧 *Girl Picture*\n\nCreator: ${data.creator}`
        }, { quoted: mek });

        // Message de confirmation simple
        await reply("✅ *Images envoyées!*");

    } catch (error) {
        console.error("Couple PP command error:", error);
        reply(`❌ Error: ${error.message || "Failed to fetch couple pictures"}`);
    }
});
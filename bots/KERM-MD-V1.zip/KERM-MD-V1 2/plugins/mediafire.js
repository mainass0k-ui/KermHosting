/**
 * Commande MediaFire Downloader
 * Télécharge et envoie le fichier directement
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "mediafire",
    alias: ["mf", "mediaf", "mfire"],
    desc: "Download files from MediaFire directly",
    category: "download",
    use: "<url>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        if (!q) {
            return reply("❌ *Usage:*\n.mediafire <url>\n\n*Example:*\n.mediafire https://www.mediafire.com/file/xxxxx/file.zip");
        }

        if (!q.includes('mediafire.com')) {
            return reply("❌ Please provide a valid MediaFire URL");
        }

        const statusMsg = await reply(`📥 *Processing MediaFire link...*\n\n⏳ Getting file information...`);

        // 1. D'abord, récupérer les infos du fichier via ton API
        const infoUrl = `https://kerm-apis.vercel.app/download/mediafire?url=${encodeURIComponent(q)}`;
        const infoRes = await axios.get(infoUrl, { timeout: 15000 });

        if (!infoRes.data || !infoRes.data.status) {
            return reply("❌ Failed to get file information");
        }

        const fileInfo = infoRes.data.result;
        
        // Mettre à jour le message de statut
        await conn.sendMessage(from, {
            text: `📥 *Downloading file...*\n\n📁 *File:* ${fileInfo.fileName}\n📊 *Size:* ${fileInfo.fileSize}\n\n⏳ Please wait...`,
            edit: statusMsg.key
        });

        // 2. Télécharger le fichier depuis l'URL de téléchargement
        const fileResponse = await axios({
            method: 'GET',
            url: fileInfo.downloadUrl,
            responseType: 'arraybuffer',
            timeout: 180000, // 3 minutes max
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });

        // 3. Déterminer le type MIME
        const mimeType = fileInfo.mimeType || 'application/octet-stream';
        
        // 4. Nom du fichier
        const fileName = fileInfo.fileName || 'mediafire_file';

        // 5. Envoyer le fichier
        await conn.sendMessage(from, {
            document: Buffer.from(fileResponse.data),
            mimetype: mimeType,
            fileName: fileName,
            caption: `✅ *Downloaded from MediaFire!*\n\n📁 *File:* ${fileName}\n📊 *Size:* ${fileInfo.fileSize}\n📍 *Uploaded from:* ${fileInfo.uploadedFrom || 'Unknown'}`
        }, { quoted: mek });

        // 6. Supprimer le message de statut
        await conn.sendMessage(from, { delete: statusMsg.key });

    } catch (error) {
        console.error("MediaFire command error:", error);
        
        if (error.response?.status === 400) {
            reply("❌ Invalid MediaFire URL");
        } else if (error.code === 'ECONNABORTED') {
            reply("❌ Download timeout. File might be too large (> 50MB).");
        } else {
            reply(`❌ Error: ${error.message || "Failed to download file"}`);
        }
    }
});
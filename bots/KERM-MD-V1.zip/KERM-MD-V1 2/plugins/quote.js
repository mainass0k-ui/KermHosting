/**
 * Commande Citations - Citations aléatoires et par catégorie
 * Utilisation: .quote (aléatoire), .quote <catégorie>
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "quote",
    alias: ["citation", "quotes"],
    desc: "Get inspirational quotes (random or by category)",
    category: "tools",
    use: "<category> (optional)",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        let url;
        let message;

        if (!q) {
            // Citation aléatoire (API externe)
            url = "https://kerm-apis.vercel.app/tools/quote/random";
            message = "🎲 *Random quote:*";
        } else {
            // Citation par catégorie (locale)
            url = `https://kerm-apis.vercel.app/tools/quote/category?cat=${encodeURIComponent(q)}`;
            message = `📚 *${q} quote:*`;
        }

        await reply(`🔄 *Fetching quote...*`);

        const res = await axios.get(url, { timeout: 10000 });

        if (!res.data || !res.data.status) {
            return reply("❌ Quote service error");
        }

        const data = res.data.result;

        // Vérifier si la catégorie existe
        if (!data.success) {
            let msg = `❌ ${data.error}\n\n`;
            msg += `*Available categories:*\n`;
            data.available.forEach(cat => {
                msg += `• ${cat}\n`;
            });
            return await reply(msg);
        }

        // Afficher la citation
        let msg = `💭 *QUOTE* 💭\n\n`;
        msg += `"${data.quote}"\n\n`;
        msg += `— *${data.author}*\n`;
        if (data.category) msg += `📌 Category: ${data.category}\n`;
        msg += `📎 Source: ${data.source}`;

        await reply(msg);

    } catch (error) {
        console.error("Quote command error:", error);
        reply(`❌ Error: ${error.message || "Failed to fetch quote"}`);
    }
});

cmd({
    pattern: "categories",
    alias: ["quotecats", "catégories"],
    desc: "List all available quote categories",
    category: "tools",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    try {
        const url = "https://kerm-apis.vercel.app/tools/quote/categories";
        const res = await axios.get(url, { timeout: 10000 });

        if (!res.data || !res.data.status) {
            return reply("❌ Failed to get categories");
        }

        const data = res.data.result;

        let msg = `📚 *QUOTE CATEGORIES* 📚\n\n`;
        
        data.categories.forEach(cat => {
            msg += `• ${cat}\n`;
        });

        msg += `\n_Use .quote <category> to get a quote_`;

        await reply(msg);

    } catch (error) {
        console.error("Quote categories error:", error);
        reply(`❌ Error: ${error.message || "Failed to get categories"}`);
    }
});
/*
_  ______   _____ _____ _____ _   _
| |/ / ___| |_   _| ____/___ | | | |
| ' / |  _    | | |  _|| |   | |_| |
| . \ |_| |   | | | |__| |___|  _  |
|_|\_\____|   |_| |_____\____|_| |_|

ANYWAY, YOU MUST GIVE CREDIT TO MY CODE WHEN COPY IT
CONTACT ME HERE +237656520674
YT: KermHackTools
Github: Kgtech-cmr
*/

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "gpt",
    alias: "ai",
    desc: "Interact with ChatGPT using the Kerm API.",
    category: "ai",
    react: "🤖",
    use: "<your query>",
    filename: __filename,
}, async (conn, mek, m, { from, args, q, reply }) => {
    try {
        // Vérification de l'entrée utilisateur
        if (!q) return reply("⚠️ Please provide a query for ChatGPT.\n\nExample:\n.gpt What is AI?");

        // Utilisation de ta nouvelle API Kerm
        const text = q;
        const encodedText = encodeURIComponent(text);
        
        // Ta nouvelle API
        const url = `https://kerm-apis.vercel.app/ai?q=${encodedText}`;

        console.log('Requesting URL:', url);

        // Appel à ta nouvelle API
        const response = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Accept': 'application/json',
            }
        });

        // Déboguer la réponse
        console.log('Full API Response:', response.data);

        // Vérification de la structure de ta réponse
        if (!response || !response.data || !response.data.status || !response.data.result) {
            return reply("❌ No valid response received from the Kerm API. Please try again later.");
        }

        // Extraire le résultat de ta nouvelle API
        const gptResponse = response.data.result;

        // Image AI
        const ALIVE_IMG = 'https://files.catbox.moe/0buoao.jpeg';

        // Légende formatée
        const formattedInfo = `🤖 *ChatGPT Response:*\n\n${gptResponse}\n\n_Powered by Kerm API_`;

        // Envoyer le message avec image et légende
        await conn.sendMessage(from, {
            image: { url: ALIVE_IMG },
            caption: formattedInfo,
            contextInfo: { 
                mentionedJid: [m.sender],
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363321386877609@newsletter',
                    newsletterName: '𝐊𝐄𝐑𝐌 𝐀𝐈',
                    serverMessageId: 143
                }
            }
        }, { quoted: mek });

    } catch (error) {
        console.error("Error in GPT command:", error);

        // Affichage détaillé de l'erreur
        if (error.response) {
            console.log("Error Response Data:", error.response.data);
            console.log("Error Status:", error.response.status);
        } else {
            console.log("Error Details:", error.message);
        }

        // Répondre avec les détails de l'erreur
        const errorMessage = `
❌ An error occurred while processing the GPT command.
🛠 *Error Details*:
${error.message}

Please report this issue or try again later.
        `.trim();
        return reply(errorMessage);
    }
});
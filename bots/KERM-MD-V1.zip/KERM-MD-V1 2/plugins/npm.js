/**
 * Commande NPM - Recherche et informations sur les packages npm
 * Utilisation: .npm <package_name>
 * Exemple: .npm axios
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "npm",
    alias: ["npminfo", "packagenpm"],
    desc: "Get information about npm packages",
    category: "tools",
    use: "<package_name>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        if (!q) {
            return reply("❌ *Usage:*\n.npm <package_name>\n\n*Examples:*\n.npm axios\n.npm express\n.npm react");
        }

        await reply(`🔍 *Searching for package "${q}"...*`);

        // D'abord essayer d'obtenir les infos directes
        const infoUrl = `https://kerm-apis.vercel.app/tools/npm/info?name=${encodeURIComponent(q)}`;
        
        try {
            const infoRes = await axios.get(infoUrl, { timeout: 10000 });
            
            if (infoRes.data && infoRes.data.status) {
                const pkg = infoRes.data.result;
                
                // Obtenir aussi les stats
                let statsText = '';
                try {
                    const statsUrl = `https://kerm-apis.vercel.app/tools/npm/stats?name=${encodeURIComponent(q)}`;
                    const statsRes = await axios.get(statsUrl, { timeout: 5000 });
                    if (statsRes.data && statsRes.data.status) {
                        const stats = statsRes.data.result;
                        statsText = `\n📊 *Downloads (30d):* ${stats.downloads.toLocaleString()}`;
                    }
                } catch (statsErr) {
                    statsText = '\n📊 *Downloads:* N/A';
                }

                let msg = `📦 *NPM PACKAGE* 📦\n\n`;
                msg += `📌 *Name:* ${pkg.name}\n`;
                msg += `🔖 *Version:* ${pkg.version}\n`;
                msg += `📝 *Description:* ${pkg.description}\n`;
                msg += `👤 *Author:* ${pkg.author}\n`;
                msg += `📜 *License:* ${pkg.license}\n`;
                msg += `🔄 *Total versions:* ${pkg.total_versions}\n`;
                msg += statsText;
                
                if (pkg.homepage) {
                    msg += `\n🌐 *Homepage:* ${pkg.homepage}`;
                }
                if (pkg.repository) {
                    msg += `\n📂 *Repository:* ${pkg.repository.replace('git+', '').replace('.git', '')}`;
                }
                
                return await reply(msg);
            }
        } catch (infoErr) {
            // Si les infos directes échouent, essayer la recherche
            const searchUrl = `https://kerm-apis.vercel.app/tools/npm/search?q=${encodeURIComponent(q)}`;
            const searchRes = await axios.get(searchUrl, { timeout: 10000 });
            
            if (searchRes.data && searchRes.data.status) {
                const results = searchRes.data.result.results;
                
                if (results.length === 0) {
                    return reply("❌ No packages found");
                }
                
                let msg = `🔍 *SEARCH RESULTS FOR "${q}"* 🔍\n\n`;
                
                results.slice(0, 5).forEach((pkg, index) => {
                    msg += `${index + 1}. *${pkg.name}* v${pkg.version}\n`;
                    msg += `   ${pkg.description}\n`;
                    if (pkg.author) msg += `   👤 ${pkg.author}\n`;
                    msg += `   🔗 ${pkg.links?.npm || `https://npmjs.com/package/${pkg.name}`}\n\n`;
                });
                
                msg += `\n_For more details: .npm <exact_package_name>_`;
                
                return await reply(msg);
            }
        }

        reply("❌ Package not found");

    } catch (error) {
        console.error("NPM command error:", error);
        reply(`❌ Error: ${error.message || "Failed to fetch package info"}`);
    }
});
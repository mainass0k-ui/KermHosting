/**
 * Commande Horoscope - Prédictions quotidiennes par signe astrologique
 * Utilisation: .horo <signe>
 * Exemple: .horo aries
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "horo",
    alias: ["horoscope", "horoscopes"],
    desc: "Get daily horoscope by zodiac sign",
    category: "tools",
    use: "<sign>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        if (!q) {
            return reply("❌ *Usage:*\n.horo <sign>\n\n*Examples:*\n.horo aries\n.horo taurus\n.horo gemini\n\n*Available signs:* aries, taurus, gemini, cancer, leo, virgo, libra, scorpio, sagittarius, capricorn, aquarius, pisces\n\n*French names also work:* belier, taureau, gemeaux, cancer, lion, vierge, balance, scorpion, sagittaire, capricorne, verseau, poissons");
        }

        await reply(`🔮 *Getting horoscope for ${q}...*`);

        const url = `https://kerm-apis.vercel.app/tools/horoscope?sign=${encodeURIComponent(q)}`;
        const res = await axios.get(url, { timeout: 15000 });

        if (!res.data || !res.data.status) {
            return reply("❌ Horoscope service error");
        }

        const data = res.data.result;

        let msg = `🔮 *HOROSCOPE* 🔮\n\n`;
        msg += `⭐ *Sign:* ${data.sign_name} (${data.sign})\n`;
        msg += `📅 *Date:* ${data.date}\n`;
        msg += `📝 *Prediction:* ${data.horoscope}\n\n`;
        msg += `🌡️ *Mood:* ${data.mood}\n`;
        msg += `💞 *Compatibility:* ${data.compatibility}\n`;
        msg += `🎨 *Color:* ${data.color}\n`;
        msg += `🍀 *Lucky Number:* ${data.lucky_number}\n`;
        msg += `⏰ *Lucky Time:* ${data.lucky_time}\n`;
        msg += `🔥 *Element:* ${data.element}\n`;
        msg += `📆 *Dates:* ${data.dates}\n`;

        await reply(msg);

    } catch (error) {
        console.error("Horoscope command error:", error);
        
        if (error.response?.status === 400) {
            reply("❌ Invalid sign. Use: aries, taurus, gemini, cancer, leo, virgo, libra, scorpio, sagittarius, capricorn, aquarius, pisces");
        } else {
            reply(`❌ Error: ${error.message || "Failed to get horoscope"}`);
        }
    }
});

cmd({
    pattern: "horosigns",
    alias: ["zodiacs", "signes"],
    desc: "List all zodiac signs",
    category: "tools",
    filename: __filename
}, async (conn, mek, m, { from, reply }) => {
    try {
        const url = `https://kerm-apis.vercel.app/tools/horoscope/signs`;
        const res = await axios.get(url, { timeout: 10000 });

        if (!res.data || !res.data.status) {
            return reply("❌ Failed to get signs");
        }

        const data = res.data.result;

        let msg = `🌟 *ZODIAC SIGNS* 🌟\n\n`;
        
        data.signs.forEach(sign => {
            msg += `• *${sign.name}* (${sign.sign})\n`;
            msg += `  📆 ${sign.dates}\n`;
            msg += `  🔥 ${sign.element}\n\n`;
        });

        msg += `\n_Use .horo <sign> to get your daily horoscope_`;

        await reply(msg);

    } catch (error) {
        console.error("Horoscope signs error:", error);
        reply(`❌ Error: ${error.message || "Failed to get signs"}`);
    }
});
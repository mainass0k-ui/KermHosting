/**
 * Commande Dictionnaire - Définitions de mots (Français/Anglais)
 * Utilisation: .dict <mot>
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "dict",
    alias: ["dictionary", "definition", "def"],
    desc: "Get word definitions (supports French & English)",
    category: "tools",
    use: "<word>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        if (!q) {
            return reply("❌ *Usage:*\n.dict <word>\n\n*Examples:*\n.dict hello\n.dict bonjour\n.dict love\n.dict amour");
        }

        await reply(`🔍 *Searching definition for "${q}"...*`);

        const url = `https://kerm-apis.vercel.app/tools/dictionary?word=${encodeURIComponent(q)}`;
        const res = await axios.get(url, { timeout: 10000 });

        if (!res.data || !res.data.status) {
            return reply("❌ Dictionary service error");
        }

        const data = res.data.result;

        let msg = `📖 *${data.word.toUpperCase()}* 📖\n\n`;
        
        if (data.language) {
            msg += `🌐 *Language:* ${data.language}\n`;
        }
        
        if (data.phonetic) {
            msg += `🔊 *Phonetic:* ${data.phonetic}\n\n`;
        }

        // Afficher les 3 premières définitions
        let defCount = 0;
        data.meanings.forEach(meaning => {
            meaning.definitions.forEach(def => {
                if (defCount < 3) {
                    msg += `*${meaning.partOfSpeech}*: ${def.definition}\n`;
                    if (def.example) {
                        msg += `📝 *Example:* "${def.example}"\n`;
                    }
                    msg += `\n`;
                    defCount++;
                }
            });
        });

        if (data.meanings.length > 3) {
            msg += `\n*And ${data.meanings.length - 3} more definitions...*`;
        }

        await reply(msg);

    } catch (error) {
        console.error("Dictionary command error:", error);
        
        if (error.response?.status === 404 || error.message.includes("not found")) {
            // Proposer des suggestions
            try {
                const suggestUrl = `https://kerm-apis.vercel.app/tools/dictionary/suggest?q=${encodeURIComponent(q)}`;
                const suggestRes = await axios.get(suggestUrl, { timeout: 5000 });
                
                if (suggestRes.data?.status && suggestRes.data.result.count > 0) {
                    let suggestMsg = `❌ Word "${q}" not found.\n\n`;
                    suggestMsg += `*Did you mean:*\n`;
                    suggestRes.data.result.suggestions.slice(0, 5).forEach(s => {
                        suggestMsg += `• ${s.word}\n`;
                    });
                    return await reply(suggestMsg);
                }
            } catch (suggestError) {
                // Ignorer les erreurs de suggestion
            }
            
            reply(`❌ Word "${q}" not found`);
        } else {
            reply(`❌ Error: ${error.message || "Failed to get definition"}`);
        }
    }
});

// La commande .suggest reste inchangée
/**
 * Commande API Info - Explore les APIs disponibles
 * Utilisation: .api, .api categories, .api <nom>
 */

const axios = require("axios");
const { cmd } = require("../command");

const API_BASE = 'https://kerm-apis.vercel.app';

cmd({
    pattern: "api",
    alias: ["apilist", "apis", "explore"],
    desc: "Explore available APIs by category",
    category: "tools",
    use: "[categories|category <name>|<api name>]",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    try {
        // ========== SI PAS DE PARAMÈTRE ==========
        if (!q) {
            const url = `${API_BASE}/api/info/stats`;
            const res = await axios.get(url, { timeout: 10000 });
            
            if (!res.data || !res.data.status) {
                return reply("❌ Failed to get API info");
            }
            
            const stats = res.data.result;
            
            let msg = `📚 *API EXPLORER* 📚\n\n`;
            msg += `📊 *Total APIs:* ${stats.total}\n`;
            msg += `✅ *Active:* ${stats.active}\n`;
            msg += `❌ *Inactive:* ${stats.inactive}\n`;
            msg += `📁 *Categories:* ${stats.categories}\n\n`;
            msg += `*Commands:*\n`;
            msg += `• .api categories - List all categories\n`;
            msg += `• .api category <name> - View APIs in a category\n`;
            msg += `• .api <api name> - Get API details\n`;
            msg += `• .api stats - Show statistics\n\n`;
            msg += `*Examples:*\n`;
            msg += `.api category search\n`;
            msg += `.api Google Search\n`;
            msg += `.api stats`;
            
            return await reply(msg);
        }
        
        // ========== PARAMÈTRE: stats ==========
        if (q.toLowerCase() === 'stats') {
            const url = `${API_BASE}/api/info/stats`;
            const res = await axios.get(url, { timeout: 10000 });
            
            if (!res.data || !res.data.status) {
                return reply("❌ Failed to get stats");
            }
            
            const stats = res.data.result;
            
            let msg = `📊 *API STATISTICS* 📊\n\n`;
            msg += `📈 *Total:* ${stats.total}\n`;
            msg += `✅ *Active:* ${stats.active}\n`;
            msg += `❌ *Inactive:* ${stats.inactive}\n`;
            msg += `📁 *Categories:* ${stats.categories}\n\n`;
            msg += `*By Category:*\n`;
            
            for (const [cat, data] of Object.entries(stats.byCategory)) {
                const activeEmoji = data.active > 0 ? '✅' : '❌';
                msg += `• *${cat}:* ${activeEmoji} ${data.active}/${data.total}\n`;
            }
            
            return await reply(msg);
        }
        
        // ========== PARAMÈTRE: categories ==========
        if (q.toLowerCase() === 'categories') {
            const url = `${API_BASE}/api/info/categories`;
            const res = await axios.get(url, { timeout: 10000 });
            
            if (!res.data || !res.data.status) {
                return reply("❌ Failed to get categories");
            }
            
            const data = res.data.result;
            
            let msg = `📁 *API CATEGORIES* 📁\n\n`;
            msg += `Total: ${data.total} APIs (${data.active} active, ${data.inactive} inactive)\n\n`;
            
            for (const [cat, catData] of Object.entries(data.categories)) {
                const activeCount = catData.apis.filter(a => a.active).length;
                const totalCount = catData.apis.length;
                const statusEmoji = activeCount === totalCount ? '✅' : (activeCount > 0 ? '⚠️' : '❌');
                
                msg += `${statusEmoji} *${cat.toUpperCase()}* (${activeCount}/${totalCount})\n`;
                
                // Afficher les 3 premières APIs de la catégorie
                catData.apis.slice(0, 3).forEach(api => {
                    const activeMark = api.active ? '✅' : '❌';
                    msg += `   ${activeMark} ${api.name}\n`;
                });
                
                if (catData.apis.length > 3) {
                    msg += `   ... and ${catData.apis.length - 3} more\n`;
                }
                msg += `\n`;
            }
            
            msg += `\n_Use .api category <name> to see all APIs in a category_`;
            
            return await reply(msg);
        }
        
        // ========== PARAMÈTRE: category <nom> ==========
        if (q.toLowerCase().startsWith('category ')) {
            const categoryName = q.substring(9).trim().toLowerCase();
            
            const url = `${API_BASE}/api/info/category/${categoryName}`;
            const res = await axios.get(url, { timeout: 10000 });
            
            if (!res.data || !res.data.status) {
                return reply(`❌ Category "${categoryName}" not found`);
            }
            
            const data = res.data.result;
            
            let msg = `📁 *CATEGORY: ${data.category.toUpperCase()}* 📁\n\n`;
            msg += `Total: ${data.count} APIs\n\n`;
            
            data.apis.forEach((api, index) => {
                const statusEmoji = api.active ? '✅' : '❌';
                msg += `${index + 1}. ${statusEmoji} *${api.name}*\n`;
                msg += `   📝 ${api.description}\n`;
                msg += `   🔗 ${api.endpoint}\n`;
                if (api.example && api.hasParam) {
                    msg += `   📌 Example: ${api.example}\n`;
                }
                msg += `\n`;
            });
            
            msg += `_Use .api <api name> to get full details_`;
            
            return await reply(msg);
        }
        
        // ========== PARAMÈTRE: nom d'API ==========
        const url = `${API_BASE}/api/info/api/${encodeURIComponent(q)}`;
        const res = await axios.get(url, { timeout: 10000 });
        
        if (!res.data || !res.data.status) {
            return reply(`❌ API "${q}" not found`);
        }
        
        const data = res.data.result;
        const api = data.api;
        
        let msg = `🔍 *API DETAILS* 🔍\n\n`;
        msg += `📌 *Name:* ${api.name}\n`;
        msg += `📝 *Description:* ${api.description}\n`;
        msg += `📁 *Category:* ${api.category}\n`;
        msg += `🔧 *Method:* ${api.method || 'GET'}\n`;
        msg += `🔗 *Endpoint:* ${api.endpoint}\n`;
        msg += `📊 *Status:* ${api.active ? '✅ Active' : '❌ Inactive'}\n`;
        
        if (api.example) {
            const baseUrl = `https://kerm-apis.vercel.app`;
            const fullUrl = baseUrl + api.endpoint + (api.hasParam ? encodeURIComponent(api.example) : '');
            msg += `\n📌 *Example:* \`${fullUrl}\`\n`;
        }
        
        if (api.icon) {
            msg += `\n🖼️ *Icon:* ${api.icon}\n`;
        }
        
        msg += `\n_Use this endpoint in your bot or applications_`;
        
        await reply(msg);

    } catch (error) {
        console.error("API Info command error:", error);
        reply(`❌ Error: ${error.message || "Failed to get API info"}`);
    }
});
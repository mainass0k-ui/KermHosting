/**
 * QR Code Command for WhatsApp Bot
 * Generates QR codes from text/URLs
 */

const axios = require("axios");
const { cmd } = require("../command");

cmd({
    pattern: "qr",
    alias: ["qrcode", "qrgen"],
    desc: "Generate QR code from text or URL",
    category: "tools",
    use: "<text or URL>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    if (!q) return reply("❌ Example: .qr https://example.com");
    
    try {
        const url = `https://kerm-apis.vercel.app/tools/qrcode?q=${encodeURIComponent(q)}&size=400`;
        const res = await axios.get(url, { timeout: 10000 });
        
        if (!res.data.status) return reply("❌ API Error");
        
        const data = res.data.result;
        
        // Send the QR code image
        await conn.sendMessage(from, {
            image: { url: data.image_url },
            caption: `✅ *QR Code Generated*\n\n📝 *Content:* ${data.text}\n📏 *Size:* ${data.size}px\n🖼️ *Format:* ${data.format}`
        }, { quoted: mek });
        
    } catch (e) {
        console.error("QR Command Error:", e.message);
        reply("❌ Error: " + e.message);
    }
});

cmd({
    pattern: "qrread",
    alias: ["qrdecode", "readqr"],
    desc: "Read/decode QR code from image URL",
    category: "tools",
    use: "<image URL>",
    filename: __filename
}, async (conn, mek, m, { from, q, reply }) => {
    if (!q) return reply("❌ Example: .qrread https://example.com/qr.png");
    
    try {
        const url = `https://kerm-apis.vercel.app/tools/qrdecode?url=${encodeURIComponent(q)}`;
        const res = await axios.get(url, { timeout: 10000 });
        
        if (!res.data.status) return reply("❌ API Error");
        
        const data = res.data.result;
        
        let msg = `✅ *QR Code Decoded*\n\n`;
        msg += `📝 *Content:* ${data.text}\n`;
        if (data.error) msg += `⚠️ *Error:* ${data.error}\n`;
        
        reply(msg);
        
    } catch (e) {
        console.error("QR Decode Command Error:", e.message);
        reply("❌ Error: " + e.message);
    }
});

/*

const moment = require("moment");
const axios = require('axios');
const config = require('../config');
const { cmd, commands } = require('../command');

cmd({
  pattern: 'qrcode',
  alias: ['qr'],
  react: '🔄',
  desc: 'Generate a QR code.',
  category: 'main',
  filename: __filename
}, async (conn, mek, m, {
  from,
  quoted,
  body,
  isCmd,
  command,
  args,
  q,
  isGroup,
  sender,
  senderNumber,
  botNumber2,
  botNumber,
  pushname,
  isMe,
  isOwner,
  groupMetadata,
  groupName,
  participants,
  groupAdmins,
  isBotAdmins,
  isAdmins,
  reply
}) => {
  try {
    if (!q) return reply('Please provide text to generate QR code.');
    await reply('> *Kerm Generating QR code...🔄*');
    const apiUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(q)}&size=200x200`;
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
    const buffer = Buffer.from(response.data, 'binary');
    
    await conn.sendMessage(m.chat, { image: buffer }, { quoted: m, caption: 'QR Code By Kerm Md' });
  } catch (error) {
    console.error(error);
    reply(`An error occurred: ${error.message}`);
  }
});

*/